# Publish.ESM.PC

## ESM PLUS Renewal

### Branch
- master : 산출물 배포
- dev : FE 개발
- mockup : 디자인 검수
- feature/jira-issue : 퍼블리싱 개발

### Folder
- dist : 배포 파일 (gulp 실행시 자동 빌드)
- src : 개발 파일

### Setting
- npm 설치 (node ver 14.x)
- gulp 실행
```
$ npm install
$ npm install -g gulp       // optional
$ gulp
```
