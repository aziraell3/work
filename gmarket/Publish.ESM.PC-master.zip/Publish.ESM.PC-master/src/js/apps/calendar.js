// $(function () {

//     CALENDARFINDER.search.set();
//     $('.form__input-day').on('keyup', function () {
//         $(this).val(
//             $(this)
//                 .val()
//                 .replace(/[^-\.0-9]/g, '')
//         );
//     });

//     $('.box__calendar .button__set-date').each(function () {
//         $(this).on('click', function () {
//             $(this).closest('.box__date').addClass('is-show');
//             $(this).removeClass('button__set-date--active');
//             $(this).addClass('button__set-date--active');
//             if ($('.box__date').hasClass('is-show')) {
//                 var currentCalendar = $(this).closest('.box__date').next();

//                 currentCalendar.show();
//                 calendar.init();
//                 CALENDARFINDER.search.init();
//             } else {
//                 $('.box__date').addClass('is-show');
//             }
//         });
//     });
// });
// CALENDARFINDER = {
//     lineType: 'RT',
//     set: {
//         date: {
//             RT: [
//                 {
//                     sId: 'start',
//                     eId: 'end',
//                     sVal: '', // 시작일
//                     eVal: '' // 종료일
//                 }
//             ]
//         }
//     } //set
// };

// CALENDARFINDER.search = {
//     init: function () {
//         this.finderInputIsEmptyDetect();
//         this.finderLayerClose();
//     },
//     set: function (setData) {
//         if (setData) {
//             $.extend(CALENDARFINDER.set, setData);
//         }
//         this.updateFinder();
//     },
//     updateFinder: function () {
//         var dataRoot = CALENDARFINDER.set;
//         var dateSplit = function (d) {
//             //년도삭제된 날짜구하기
//             return d.substr(5, 9);
//         };
//         //날짜
//         Object.keys(dataRoot.date).forEach(function (k) {
//             for (i = 0; i < dataRoot.date[k].length; i++) {
//                 var sId = dataRoot.date[k][i].sId;
//                 var sVal = dataRoot.date[k][i].sVal;
//                 var sDay = dataRoot.date[k][i].sDay;
//                 var shortD = dateSplit(sVal);

//                 if (k == 'RT') {
//                     var eId = dataRoot.date[k][i].eId;
//                     var eVal = dataRoot.date[k][i].eVal;
//                 }
//             }
//         });
//         CALENDARFINDER.search.finderInputIsEmptyDetect();
//     },
//     finderInputIsEmptyDetect: function () {
//         var $inputs = $('.form__input-day');
//         $inputs.each(function () {
//             var $this = $(this);
//             if ($this.val()) {
//                 $this.removeClass('form__input--placeholder-shown');
//             } else {
//                 $this.addClass('form__input--placeholder-shown');
//             }
//         });
//     },
//     finderLayerClose: function () {
//         // 외부영역 클릭 시 팝업 닫기
//         $(document).on('mouseup', function (e) {
//             var $layerPopup = $('.box__layer-calendar');
//             if ($layerPopup.has(e.target).length === 0) {
//                 $('.box__date').removeClass('is-show');
//             }
//         });
//     }
// };
// var calendar = {
//     init: function () {
//         this.container.datepicker('destroy');
//         this.getDate();
//         this.callDraw();
//     },
//     container: $('.box__datepicker'),
//     numberOfMonths: 2,
//     dateFormat: 'yy.mm.dd',
//     dayNamesMin: ['일', '월', '화', '수', '목', '금', '토'],
//     showMonthAfterYear: true,
//     inputs: {
//         day1: '#start',
//         day2: '#end'
//     },
//     dates: ['', '', ''], //날짜 temporal store
//     days: ['', '', ''], //요일
//     hoverEve: false,
//     setHDay: function () {
//         this.callDraw();
//     },
//     getDate: function () {
//         // strored date get
//         var d1 = '',
//             d2 = '';
//         var line = CALENDARFINDER.lineType;
//         var dateRoot = CALENDARFINDER.set.date[line];
//         d1 = CALENDARFINDER.set.date[CALENDARFINDER.lineType][0].sVal !== '' ? dateRoot[0].sVal : '';
//         d2 = line == 'RT' ? dateRoot[0].eVal : dateRoot[1].sVal;
//         this.updateDates(d1, d2);
//     },
//     updateDates: function (d1, d2) {
//         //날짜
//         for (i = 0; i < 2; i++) {
//             //dates 배열, 날짜 저장
//             var n = i + 1;
//             this.dates[i] = eval('d' + n);
//             $(this.inputs['day' + n]).val(this.dates[i]);
//         }
//         CALENDARFINDER.search.finderInputIsEmptyDetect();
//     },
//     storeDates: function () {
//         //데이터 저장
//         var d1 = this.dates[0];
//         var d2 = this.dates[1];
//         var dateSplit = function (d) {
//             //년도삭제된 날짜구하기
//             return d.substr(5, 9);
//         };

//         var line = CALENDARFINDER.lineType;
//         var dataRoot = CALENDARFINDER.set.date[line];

//         if (d1 !== '' && line == 'RT') {
//             // 시작일
//             $('#' + dataRoot[0].sId).val(d1);
//             $('#' + dataRoot[0].eId).val('');
//             dataRoot[0].sVal = d1;
//             dataRoot[0].eVal = '';
//         }
//         if (d1 !== '' && d2 !== '' && line == 'RT') {
//             // 종료일
//             $('#' + dataRoot[0].sId).val(d1);
//             $('#' + dataRoot[0].eId).val(d2);
//             dataRoot[0].sVal = d1;
//             dataRoot[0].eVal = d2;
//         }

//         CALENDARFINDER.search.finderInputIsEmptyDetect();
//     },
//     callDraw: function () {
//         drawAirDatepicker();
//     },
//     dateHover: function (selectDate) {
//         var $box = $('#datepicker');
//         var target = 'td[data-handler="selectDay"]';
//         var mClass = 'ui-datepicker-move-day';
//         var imClass = 'ui-datepicker-move-important';
//         if (typeof $box.get(0) === 'undefined') return false;
//         if (!calendar.hoverEve) {
//             $box.on('mouseenter', target, function () {
//                 var inOut = CALENDARFINDER.lineType;
//                 var eveTarget = $box.find('td[data-event=click]');
//                 var startDate = selectDate;
//                 var thisNum = calendar.returnDateNumber_etc($(this).attr('data-year'), $(this).attr('data-month'), $(this).text());
//                 var stdNum = calendar.returnDateNumber_etc(startDate.getFullYear(), startDate.getMonth(), startDate.getDate());
//                 if (inOut !== 'RT') return false;
//                 if (thisNum <= stdNum) {
//                     eveTarget.removeClass(mClass);
//                     $(this).removeClass(imClass);
//                 } else {
//                     eveTarget.removeClass(mClass);
//                     $(this).addClass(imClass);
//                     $.each(eveTarget, function () {
//                         var $this = $(this);
//                         var n = calendar.returnDateNumber_etc($this.attr('data-year'), $this.attr('data-month'), $this.find('a').text());
//                         if (thisNum > n && n > stdNum) {
//                             $this.addClass(mClass);
//                         }
//                     });
//                 }
//             }).on('mouseleave', target, function () {
//                 $box.find('td.' + mClass).removeClass(mClass);
//                 $(this).removeClass(imClass);
//             });
//         } else {
//             $box.on('mouseenter', target, function () {
//                 $box.find('td.' + mClass).removeClass(mClass);
//                 $(this).removeClass(imClass);
//             });
//         }
//     },
//     returnDateNumber_etc: function (y, m, d) {
//         return parseInt(String(y) + String(m > 9 ? m : '0' + m) + String(d > 9 ? d : '0' + d), 10);
//     }
// };
// var drawAirDatepicker = function () {
//     //layer input jquery객체
//     var $d1 = $(calendar.inputs.day1);
//     var $d2 = $(calendar.inputs.day2);
//     var line = CALENDARFINDER.lineType;

//     var parsedate = function (d) {
//         return $.datepicker.parseDate(calendar.dateFormat, d);
//     };

//     calendar.container.datepicker({
//         numberOfMonths: 2,
//         dateFormat: calendar.dateFormat,
//         showMonthAfterYear: true,
//         status: null,
//         monthNames: ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12'],
//         monthNamesShort: ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월'],
//         dayNames: ['일요일', '월요일', '화요일', '수요일', '목요일', '금요일', '토요일'],
//         dayNamesMin: ['일', '월', '화', '수', '목', '금', '토'],
//         yearSuffix: '.',
//         minDate: 0,
//         maxDate: '366d',
//         setDate: 'today',
//         beforeShowDay: function (date) {
//             var date1 = parsedate($d1.val());
//             var date2 = parsedate($d2.val());
//             var $today = new Date().getFullYear() + '.' + ('0' + (new Date().getMonth() + 1)).slice(-2) + '.' + ('0' + new Date().getDate()).slice(-2);
//             var classes = {
//                 highlight: 'ui-datepicker-highlight',
//                 start: 'ui-datepicker-start-day'
//             };
//             var checkText = '';
//             var os_express = '';
//             for (var i = 0; i < calendar.dates.length; i++) {
//                 if (i == 0) {
//                     checkText = $today === $d2.val() ? '당일' : '시작일';
//                 } else if (i == 1) {
//                     checkText = '종료일';
//                 }
//                 var stringifyD = calendar.dates[i].toString();
//                 var paseD = new Date(stringifyD.replace(/\./g, '/'));
//                 if (paseD == date.toString()) {
//                     return [true, 'ui-point', '' + checkText + ''];
//                 } //point 표시 출력
//             }

//             //하이라이트
//             var highlightCondition = date1 && (date == date1 || (date2 && date >= date1 && date <= date2));

//             return [true, highlightCondition ? classes.highlight : '']; // range 표시 클래스 출력
//         },
//         onSelect: function (dateText, inst) {
//             var d1, d2;
//             d1 = $d1.val();
//             d2 = $d2.val();
//             var day = new Date(dateText.replace(/\./g, '/'));

//             if (!d1 || (line == 'RT' && d2)) {
//                 $d1.val(dateText); // first input print
//                 calendar.dates[0] = dateText;
//                 calendar.dates[1] = '';
//                 calendar.hoverEve = false;
//                 $(this).datepicker();
//             } else if (!d2 && line == 'RT') {
//                 $d2.val(dateText);
//                 calendar.dates[1] = dateText;
//                 calendar.dates[2] = '';
//                 calendar.hoverEve = true;
//                 calendar.storeDates();
//                 $('.box__layer-calendar').hide();
//                 $('.box__date').removeClass('is-show');
//                 $(this).datepicker();
//             }
//             calendar.dateHover(day);
//             CALENDARFINDER.search.finderInputIsEmptyDetect();
//         }
//     });
// }; //drawAirDatepicker


// =================================================>
const renew = (() => {
    const CALENDARFINDER = {
        lineType: 'RT',
        set: {
            date: {
                RT: [
                    {
                        sId: 'start',
                        eId: 'end',
                        sVal: '', // 시작일
                        eVal: '' // 종료일
                    }
                ]
            }
        }, //set
        search: {
            init: function () {
                this.finderInputIsEmptyDetect();
                this.finderLayerClose();
            },
            set: function (setData) {
                if (setData) {
                    $.extend(CALENDARFINDER.set, setData);
                }
                this.updateFinder();
            },
            updateFinder: function () {
                var dataRoot = CALENDARFINDER.set;
                var dateSplit = function (d) {
                    //년도삭제된 날짜구하기
                    return d.substr(5, 9);
                };
                //날짜
                Object.keys(dataRoot.date).forEach(function (k) {
                    for (i = 0; i < dataRoot.date[k].length; i++) {
                        var sId = dataRoot.date[k][i].sId;
                        var sVal = dataRoot.date[k][i].sVal;
                        var sDay = dataRoot.date[k][i].sDay;
                        var shortD = dateSplit(sVal);

                        if (k == 'RT') {
                            var eId = dataRoot.date[k][i].eId;
                            var eVal = dataRoot.date[k][i].eVal;
                        }
                    }
                });
                CALENDARFINDER.search.finderInputIsEmptyDetect();
            },
            finderInputIsEmptyDetect: function () {
                var $inputs = $('.form__input-day');
                $inputs.each(function () {
                    var $this = $(this);
                    if ($this.val()) {
                        $this.removeClass('form__input--placeholder-shown');
                    } else {
                        $this.addClass('form__input--placeholder-shown');
                    }
                });
            },
            finderLayerClose: function () {
                // 외부영역 클릭 시 팝업 닫기
                $(document).on('mouseup', function (e) {
                    var $layerPopup = $('.box__layer-calendar');
                    if ($layerPopup.has(e.target).length === 0) {
                        $layerPopup.removeClass("is-show")
                    }
                });
            }
        }
    };

    const calendar = {
        init: function () {
            this.container.datepicker('destroy');
            this.getDate();
            this.callDraw();
        },
        container: $('.box__datepicker'),
        numberOfMonths: 2,
        dateFormat: 'yy.mm.dd',
        dayNamesMin: ['일', '월', '화', '수', '목', '금', '토'],
        showMonthAfterYear: true,
        inputs: {
            day1: '#start',
            day2: '#end'
        },
        dates: ['', '', ''], //날짜 temporal store
        days: ['', '', ''], //요일
        hoverEve: false,
        setHDay: function () {
            this.callDraw();
        },
        getDate: function () {
            // strored date get
            var d1 = '',
                d2 = '';
            var line = CALENDARFINDER.lineType;
            var dateRoot = CALENDARFINDER.set.date[line];

            d1 = CALENDARFINDER.set.date[CALENDARFINDER.lineType][0].sVal !== '' ? dateRoot[0].sVal : '';
            d2 = line == 'RT' ? dateRoot[0].eVal : dateRoot[1].sVal;
            this.updateDates(d1, d2);
        },
        updateDates: function (d1, d2) {
            //날짜
            for (i = 0; i < 2; i++) {
                //dates 배열, 날짜 저장
                var n = i + 1;
                this.dates[i] = eval('d' + n);
                $(this.inputs['day' + n]).val(this.dates[i]);
            }
            CALENDARFINDER.search.finderInputIsEmptyDetect();
        },
        storeDates: function () {
            //데이터 저장
            var d1 = this.dates[0];
            var d2 = this.dates[1];
            var dateSplit = function (d) {
                //년도삭제된 날짜구하기
                return d.substr(5, 9);
            };
            var line = CALENDARFINDER.lineType;
            var dataRoot = CALENDARFINDER.set.date[line];

            if (d1 !== '' && line == 'RT') {
                $('#' + dataRoot[0].sId).val(d1);
                $('#' + dataRoot[0].eId).val('');
                dataRoot[0].sVal = d1;
                dataRoot[0].eVal = d2;
            }

            if (d1 === '' && d2 !== '' && line == 'RT') {
                $('#' + dataRoot[0].sId).val(d1);
                $('#' + dataRoot[0].eId).val(d2);
                dataRoot[0].sVal = d1;
                dataRoot[0].eVal = d2;
            }
            CALENDARFINDER.search.finderInputIsEmptyDetect();
        },
        callDraw: function () {
            drawAirDatepicker();
        },
        dateHover: function (selectDate) {
            var $box = $('#datepicker');
            var target = 'td[data-handler="selectDay"]';
            var mClass = 'ui-datepicker-move-day';
            var imClass = 'ui-datepicker-move-important';

            if (typeof $box.get(0) === 'undefined') return false;
            if (!calendar.hoverEve) {
                $box.on('mouseenter', target, function () {
                    var inOut = CALENDARFINDER.lineType;
                    var eveTarget = $box.find('td[data-event=click]');
                    var startDate = selectDate;
                    var thisNum = calendar.returnDateNumber_etc($(this).attr('data-year'), $(this).attr('data-month'), $(this).text());
                    var stdNum = calendar.returnDateNumber_etc(startDate.getFullYear(), startDate.getMonth(), startDate.getDate());
                    if (inOut !== 'RT') return false;
                    if (thisNum <= stdNum) {
                        eveTarget.removeClass(mClass);
                        $(this).addClass(mClass);
                        $.each(eveTarget, function () {
                            var $this = $(this);
                            var n = calendar.returnDateNumber_etc($this.attr('data-year'), $this.attr('data-month'), $this.find('a').text());
                            if (thisNum < n && n < stdNum) {
                                $this.addClass(mClass);
                            }
                        });
                    } else {
                        eveTarget.removeClass(mClass);
                        $(this).addClass(imClass);
                        $.each(eveTarget, function () {
                            var $this = $(this);
                            var n = calendar.returnDateNumber_etc($this.attr('data-year'), $this.attr('data-month'), $this.find('a').text());
                            if (thisNum > n && n > stdNum) {
                                $this.addClass(mClass);
                            }
                        });
                    }
                }).on('mouseleave', target, function () {
                    $box.find('td.' + mClass).removeClass(mClass);
                    $(this).removeClass(imClass);
                });
            } else {
                $box.on('mouseenter', target, function () {
                    $box.find('td.' + mClass).removeClass(mClass);
                    $(this).removeClass(imClass);
                });
            }
        },
        returnDateNumber_etc: function (y, m, d) {
            return parseInt(String(y) + String(m > 9 ? m : '0' + m) + String(d > 9 ? d : '0' + d), 10);
        }
    };

    const drawAirDatepicker = function () {
        //layer input jquery객체
        var $d1 = $(calendar.inputs.day1);
        var $d2 = $(calendar.inputs.day2);
        var line = CALENDARFINDER.lineType;
        var parsedate = function (d) {
            return $.datepicker.parseDate(calendar.dateFormat, d);
        };

        calendar.container.datepicker({
            numberOfMonths: 2,
            dateFormat: calendar.dateFormat,
            showMonthAfterYear: true,
            status: null,
            monthNames: ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12'],
            monthNamesShort: ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월'],
            dayNames: ['일요일', '월요일', '화요일', '수요일', '목요일', '금요일', '토요일'],
            dayNamesMin: ['일', '월', '화', '수', '목', '금', '토'],
            yearSuffix: '.',
            minDate: 0,
            maxDate: '366d',
            setDate: 'today',
            beforeShowDay: function (date) {
                var date1 = parsedate($d1.val());
                var date2 = parsedate($d2.val());
                var $today = new Date().getFullYear() + '.' + ('0' + (new Date().getMonth() + 1)).slice(-2) + '.' + ('0' + new Date().getDate()).slice(-2);
                var classes = {
                    highlight: 'ui-datepicker-highlight',
                    start: 'ui-datepicker-start-day'
                };
                var checkText = '';
                var os_express = '';
                for (var i = 0; i < calendar.dates.length; i++) {
                    if (i == 0) {
                        checkText = $today === $d2.val() ? '당일' : '시작일';
                    } else if (i == 1) {
                        checkText = '종료일';
                    }
                    var stringifyD = calendar.dates[i].toString();
                    var paseD = new Date(stringifyD.replace(/\./g, '/'));
                    if (paseD == date.toString()) {
                        return [true, 'ui-point', '' + checkText + ''];
                    } //point 표시 출력
                }
                //하이라이트
                var highlightCondition = date1 && (date == date1 || (date2 && date >= date1 && date <= date2));
                return [true, highlightCondition ? classes.highlight : '']; // range 표시 클래스 출력
            },

            onSelect: function (dateText, inst) {
                var d1, d2;
                d1 = $d1.val();
                d2 = $d2.val();
                var day = new Date(dateText.replace(/\./g, '/'));

                if (!d1 || (line == 'RT' && d2)) {
                    $d1.val(dateText); // first input print
                    calendar.dates[0] = dateText;
                    calendar.dates[1] = '';
                    calendar.hoverEve = false;
                    calendar.storeDates();
                    $(this).datepicker();

                } else if (!d2 && line == 'RT') {
                    $d2.val(dateText);
                    calendar.dates[1] = dateText;
                    calendar.dates[2] = '';
                    calendar.hoverEve = true;
                    calendar.storeDates();
                    $(this).datepicker();
                }
                calendar.dateHover(day);
                CALENDARFINDER.search.finderInputIsEmptyDetect();
            }
        });
    };

    CALENDARFINDER.search.set();
    $('.form__input-day').on('keyup', function () {
        $(this).val(
            $(this)
                .val()
                .replace(/[^-\.0-9]/g, '')
        );
    });

    $('.box__calendar .box__date').on('click', function(){
        const box__layercontainer = $(this).next();
        box__layercontainer.addClass("is-show")
        calendar.init();
        CALENDARFINDER.search.init();
    })

    $('.button__wrap .button--blue').on('click', function () {
        const box__calendar = $(this).closest(".box__layer-calendar")
        box__calendar.removeClass('is-show')
    })
})()
