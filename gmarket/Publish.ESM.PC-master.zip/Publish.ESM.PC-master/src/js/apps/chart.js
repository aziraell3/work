const byBoxCanvas = document.getElementById('myChart')
const cumulativeCanvas = document.getElementById('cumulativeSales')
const todaySales = document.getElementById('todaySales')
const paidCanvas = document.getElementById('todayPaid')
const incomingCanvas = document.getElementById('todayIncoming')
const tableCanvas = document.getElementById('tableChart')

const timeLine = ['01:00', '02:00', '03:00', '04:00', '05:00', '06:00', '07:00', '08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00', '23:00', '24:00' ]

const linearData = [
    // 누적판매현황 gray 선그래프, y축 데이터
    [100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100],

    // 누적판매현황 blue 선그래프, y축 데이터
    [200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200,200,200,200,200]
]

const barData = [
    [100, 100, 100, 100, 100, 100, 100, 100, 50, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100],

    [200, 200, 200, 200, 200, 200, 200, 200, 100, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200,200,200,200,200]
]

const chartCanvasId = ['cumulativeSales', "todaySales", "paidNumber",'incomingNumber']

const chartType ={
    linear:{
        linearTypeBlue:{
            type: 'line',
            fill: false,
            borderWidth: 2,
            borderColor: 'rgba(6, 125, 253, 1)',
            backgroundColor: 'rgba(6, 125, 253, 1)',
            pointStyle: "circleRot",
            pointRadius: 5,
            pointBorderWidth: 2,
            pointBorderColor: 'rgba(255, 255, 255, 1)',
            pointBackgroundColor: 'rgba(6, 125, 253, 1)',
            pointHoverRadius: 5,
            pointHoverBorderWidth: 14,
            pointHoverBorderColor: 'rgba(6, 125, 253, 0.2)',
            pointHoverBackgroundColor: 'rgba(6, 125, 253, 1)',
        },
        linearTypeGray:{
            type: 'line',
            fill: false,
            borderWidth: 2,
            borderColor: 'rgba(158, 158, 158, 1)',
            backgroundColor: 'rgba(158, 158, 158, 1)',
            pointStyle: "circleRot",
            pointRadius: 5,
            pointBorderWidth: 2,
            pointBorderColor: 'rgba(255, 255, 255, 1)',
            pointBackgroundColor: 'rgba(158, 158, 158, 1)',
            pointHoverRadius: 5,
            pointHoverBorderWidth: 14,
            pointHoverBorderColor: 'rgba(158, 158, 158, 0.2)',
            pointHoverBackgroundColor: 'rgba(158, 158, 158, 1)',
        }
    },
    bar:{
        barTypeBlue:{
            type: 'bar',
            fill: false,
            borderColor: 'rgba(50, 156, 255, 1)',
            backgroundColor: 'rgba(50, 156, 255, 1)',
            hoverBorderColor: 'rgba(50, 156, 255, 1)',
            hoverBackgroundColor: 'rgba(50, 156, 255, 1)',
        },
        barTypePink: {
            type: 'bar',
            fill: false,
            borderColor: 'rgba(255, 191, 191, 1)',
            backgroundColor: 'rgba(255, 191, 191, 1)',
            hoverBorderColor: 'rgba(255, 191, 191, 1)',
            hoverBackgroundColor: 'rgba(255, 191, 191, 1)',
        },
    }
}

const chartCommonOptions = {
    responsive: false,
    scales: {
        x: {
            beginAtZero: true,
            border: {
                display: false,
            },
            grid: {
                display: false,
            },
            ticks: {
                fontSize: 12,
                color: '#757575',
            },
            offset: true
        },
        y: {
            display: true,
            position: 'left',
            beginAtZero: true,
            border: {
                display: false,
            },
            grid: {
                color: '#e0e0e0',
                tickLength: 10,
            },
            ticks: {
                padding: 16,
                fontSize: 12,
                color: '#757575',
                maxTicksLimit: 10,
            },
            offset: true
        },
    },
    plugins: {
        legend: {
            display: false,
        },
        tooltip: {
            enabled: false,
        },
    }
}

const generateDataSet = (dataXAxis, dataYAxis ) =>{
    if (dataXAxis.length !== dataYAxis.length) {
        throw new Error("입력값, dataXAxis와 dataYAxis의 데이터수가 일치 하지 않습니다,");
    }

    const result = [];
    for (let i = 0; i < dataXAxis.length; i++) {
        result.push({ x: dataXAxis[i], y: dataYAxis[i] });
    }
    return result;
}

const { linear: { linearTypeBlue, linearTypeGray, barTypeBlue, barTypePink } } = chartType

const linearUpperGraphData = generateDataSet(timeLine, linearData[0])
const linearLowerGraphData = generateDataSet(timeLine, linearData[1])
const barUpperGraphData = generateDataSet(timeLine, barData[0])
const barLowerGraphData = generateDataSet(timeLine, barData[1])

if (byBoxCanvas){
    const chartFunction = (function (container) {

        const opts = {
            container: container || '.box__chart',
            legend: '#legend'
        };

        return {
            init: function() {
                if (!(this.container = $(opts.container)).length) return;
                this.chartOptions();
                this.setElements();
            },
            setElements: function() {
                this.legend = this.container.find(opts.legend);
            },
            chartOptions: function() {
                const timePack = ['09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00', '23:00', '24:00'];
                const context = document.getElementById('myChart').getContext('2d');

                // Chart.defaults.global.defaultFontSize = 12;
                // Chart.defaults.global.defaultFontColor = '#757575';

                this.myChart = new Chart(context, {
                    type: 'line',
                    data: {
                        labels: timePack,
                        datasets: [
                            // 현재 내 상품 가격
                            {
                                data: [
                                    { x: '09:00', y: 100 },
                                    { x: '10:00', y: 100 },
                                    { x: '11:00', y: 100 },
                                    { x: '12:00', y: 100 },
                                    { x: '13:00', y: 100 },
                                    { x: '14:00', y: 100 },
                                    { x: '15:00', y: 100 },
                                    { x: '16:00', y: 100 },
                                    { x: '17:00', y: 100 },
                                    { x: '18:00', y: 100 },
                                    { x: '19:00', y: 100 },
                                    { x: '20:00', y: 100 },
                                    { x: '21:00', y: 100 },
                                    { x: '22:00', y: 100 },
                                    { x: '23:00', y: 100 },
                                    { x: '24:00', y: 100 },
                                ],
                                type: 'line',
                                fill: false,
                                borderWidth: 2,
                                borderDash: [4, 6],
                                borderColor: 'rgba(6, 125, 253, 1)',
                                pointRadius: 0,
                                backgroundColor: 'transparent',
                                borderCapStyle: 'round'
                            },
                            // 내 상품 가격
                            {
                                data: [
                                    { x: '09:00', y: 55 },
                                    { x: '10:00', y: 55 },
                                    { x: '11:00', y: 55 },
                                    { x: '12:00', y: 55 },
                                    { x: '13:00', y: 55 },
                                    { x: '14:00', y: 55 },
                                    { x: '15:00', y: 55 },
                                    { x: '16:00', y: 55 },
                                    { x: '17:00', y: 55 },
                                    { x: '18:00', y: 55 },
                                    { x: '19:00', y: 55 },
                                    { x: '20:00', y: 55 },
                                    { x: '21:00', y: 55 },
                                    { x: '22:00', y: 55 },
                                    { x: '23:00', y: 55 },
                                    { x: '24:00', y: 55 },
                                ],
                                type: 'line',
                                fill: false,
                                borderWidth: 2,
                                borderColor: 'rgba(6, 125, 253, 1)',
                                backgroundColor: 'rgba(6, 125, 253, 1)',
                                pointStyle: "circleRot",
                                pointRadius: 5,
                                pointBorderWidth: 2,
                                pointBorderColor: 'rgba(255, 255, 255, 1)',
                                pointBackgroundColor: 'rgba(6, 125, 253, 1)',
                                pointHoverRadius: 5,
                                pointHoverBorderWidth: 14,
                                pointHoverBorderColor: 'rgba(6, 125, 253, 0.2)',
                                pointHoverBackgroundColor: 'rgba(6, 125, 253, 1)',
                            },
                            // 가격비교 최저가
                            {
                                data: [
                                    { x: '09:00', y: 10 },
                                    { x: '10:00', y: 10 },
                                    { x: '11:00', y: 10 },
                                    { x: '12:00', y: 10 },
                                    { x: '13:00', y: 10 },
                                    { x: '14:00', y: 10 },
                                    { x: '15:00', y: 10 },
                                    { x: '16:00', y: 10 },
                                    { x: '17:00', y: 10 },
                                    { x: '18:00', y: 10 },
                                    { x: '19:00', y: 10 },
                                    { x: '20:00', y: 10 },
                                    { x: '21:00', y: 10 },
                                    { x: '22:00', y: 10 },
                                    { x: '23:00', y: 10 },
                                    { x: '24:00', y: 10 },
                                ],
                                type: 'line',
                                fill: false,
                                borderWidth: 2,
                                borderColor: 'rgba(158, 158, 158, 1)',
                                backgroundColor: 'rgba(158, 158, 158, 1)',
                                pointStyle: "circleRot",
                                pointRadius: 5,
                                pointBorderWidth: 2,
                                pointBorderColor: 'rgba(255, 255, 255, 1)',
                                pointBackgroundColor: 'rgba(158, 158, 158, 1)',
                                pointHoverRadius: 5,
                                pointHoverBorderWidth: 14,
                                pointHoverBorderColor: 'rgba(158, 158, 158, 0.2)',
                                pointHoverBackgroundColor: 'rgba(158, 158, 158, 1)',
                            }
                        ]
                    },
                    options: {
                        // maintainAspectRatio: false,
                        responsive: false,
                        scales: {
                            x: {
                                beginAtZero: true,
                                border: {
                                  display: false,
                                },
                                grid: {
                                    display: false,
                                },
                                ticks: {
                                    fontSize: 12,
                                    color: '#757575',
                                },
                            },
                            y: {
                                display: true,
                                position: 'left',
                                beginAtZero: true,
                                border: {
                                  display: false,
                                },
                                grid: {
                                    color: '#e0e0e0',
                                    tickLength: 10,
                                },
                                ticks: {
                                    padding: 16,
                                    fontSize: 12,
                                    color: '#757575',
                                    maxTicksLimit: 10,
                                },
                            },
                            y1: {
                                display: true,
                                position: 'right',
                                beginAtZero: true,
                                border: {
                                  display: false,
                                },
                                grid: {
                                    color: '#e0e0e0',
                                    tickLength: 10,
                                },
                                ticks: {
                                    display: false,

                                    maxTicksLimit: 10,
                                },
                            },
                        },
                        plugins: {
                            legend: {
                                display: false,

                            },
                            tooltip: {
                                enabled: false,
                            },
                        }
                    },
                });
            }
        }
    })();
    chartFunction.init();
}

if (cumulativeCanvas){
    const chartCumulative=((container)=>{
            const opts = {
                container: container || '.box__chart',
                legend: '#legend'
            };
            return {
                init(){
                    if (!(this.container = $(opts.container)).length) return;
                    this.chartOptions();
                },
                chartOptions(){
                    this.myChart = new Chart(document.getElementById('cumulativeSales').getContext('2d'), {
                        type: 'line',
                        data: {
                            labels: timeLine,
                            datasets: [
                                {
                                    data: linearUpperGraphData,
                                    ...linearTypeGray
                                },

                                {
                                    data: linearLowerGraphData,
                                    ...linearTypeBlue
                                }
                            ]
                        },
                        options: chartCommonOptions
                    });
                }
            }
    })(container);
    chartCumulative.init();
}

if (todaySales){
    const chartSales = ((container)=>{
        const opts = {
            container: container || '.box__chart',
            legend: '#legend'
        };
        return {
            init(){
                if (!(this.container = $(opts.container)).length) return;
                this.chartOptions();
            },
            chartOptions(){
                this.myChart = new Chart(document.getElementById('todaySales').getContext('2d'), {
                    type: 'bar',
                    data: {
                        labels: timeLine,
                        datasets: [
                            {
                                data: barUpperGraphData,
                                ...barTypeBlue
                            },

                            {
                                data: barLowerGraphData,
                                ...barTypePink
                            }
                        ]
                    },
                    options: chartCommonOptions
                });
            }
        }
    })(container)
    chartSales.init();
}

if (paidCanvas){
    const chartPaid = ((container)=>{
        const opts = {
            container: container || '.box__chart',
            legend: '#legend'
        };
        return {
            init(){
                if (!(this.container = $(opts.container)).length) return;
                this.chartOptions();
            },
            chartOptions(){
                this.myChart = new Chart(document.getElementById('todayPaid').getContext('2d'), {
                    type: 'line',
                    data: {
                        labels: timeLine,
                        datasets: [
                            {
                                data: linearUpperGraphData,
                                ...linearTypeGray
                            },

                            {
                                data: linearLowerGraphData,
                                ...linearTypeBlue
                            }
                        ]
                    },
                    options: chartCommonOptions
                });

            }
        }
    })(container)
    chartPaid.init();
}

if (incomingCanvas){
    const chartIncoming = ((container) => {
        const opts = {
            container: container || '.box__chart',
            legend: '#legend'
        };
        return {
            init(){
                if (!(this.container = $(opts.container)).length) return;
                this.chartOptions();
            },
            chartOptions(){
                this.myChart = new Chart(document.getElementById('todayIncoming').getContext('2d'), {
                    type: 'line',
                    data: {
                        labels: timeLine,
                        datasets: [
                            {
                                data: linearUpperGraphData,
                                ...linearTypeGray
                            },

                            {
                                data: linearLowerGraphData,
                                ...linearTypeBlue
                            }
                        ]
                    },
                    options: chartCommonOptions
                });
            }
        }
    })(container)

    chartIncoming.init();
}

if (tableCanvas){

    const chartTable = ((container) => {
        const opts = {
            container: container || '.box__chart',
            legend: '#legend'
        };
        return {
            init(){
                if (!(this.container = $(opts.container)).length) return;
                this.chartOptions();
            },
            chartOptions(){
                this.myChart = new Chart(document.getElementById('tableChart').getContext('2d'), {
                    type: 'bar',
                    data: {
                        labels: timeLine,
                        datasets: [
                            {
                                data: barUpperGraphData,
                                ...barTypeBlue
                            },

                            {
                                data: barLowerGraphData,
                                ...barTypePink
                            }
                        ]
                    },
                    options: chartCommonOptions
                });
            }
        }
    })(container)
    chartTable.init();
}

